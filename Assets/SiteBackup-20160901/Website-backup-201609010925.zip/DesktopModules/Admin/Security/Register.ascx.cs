﻿#region Copyright

// 
// DotNetNuke® - http://www.dotnetnuke.com
// Copyright (c) 2002-2014
// by DotNetNuke Corporation
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.

#endregion

#region Usings

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;

using DotNetNuke.Common;
using DotNetNuke.Common.Lists;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Host;
using DotNetNuke.Entities.Modules;
using DotNetNuke.Entities.Users;
using DotNetNuke.Entities.Users.Internal;
using DotNetNuke.Framework;
using DotNetNuke.Modules.Dashboard.Components.Portals;
using DotNetNuke.Security;
using DotNetNuke.Security.Membership;
using DotNetNuke.Security.Permissions;
using DotNetNuke.Services.Authentication;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Services.Localization;
using DotNetNuke.UI.Skins.Controls;
using DotNetNuke.Entities.Profile;
using DotNetNuke.Web.Client.ClientResourceManagement;
using DotNetNuke.Web.UI.WebControls;
using DotNetNuke.UI.WebControls;
using System.Web.UI.WebControls;
using DotNetNuke.Entities.Users.Membership;

#endregion

namespace DotNetNuke.Modules.Admin.Users
{
	public partial class Register : UserUserControlBase
	{
		protected const string PasswordStrengthTextBoxCssClass = "password-strength";
		protected const string ConfirmPasswordTextBoxCssClass = "password-confirm";

		private readonly List<AuthenticationLoginBase> _loginControls = new List<AuthenticationLoginBase>();

		#region Protected Properties

		protected string AuthenticationType
		{
			get
			{
				return ViewState.GetValue("AuthenticationType", Null.NullString);
			}
			set
			{
				ViewState.SetValue("AuthenticationType", value, Null.NullString);
			}
		}

		protected UserCreateStatus CreateStatus { get; set; }

		protected string ExcludeTerms
		{
			get
			{
				string regex = String.Empty;
				if (!String.IsNullOrEmpty(PortalSettings.Registration.ExcludeTerms))
				{
					regex = @"^(?:(?!" + PortalSettings.Registration.ExcludeTerms.Replace(" ", "").Replace(",", "|") + @").)*$\r?\n?";
				}
				return regex;
			}
		}

		protected bool IsValid
		{
			get
			{
				return Validate();
			}
		}

		protected string UserToken
		{
			get
			{
				return ViewState.GetValue("UserToken", string.Empty);
			}
			set
			{
				ViewState.SetValue("UserToken", value, string.Empty);
			}
		}

		#endregion

		#region Event Handlers

		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);

			jQuery.RequestDnnPluginsRegistration();

			ClientResourceManager.RegisterScript(Page, "~/Resources/Shared/scripts/dnn.jquery.extensions.js");
			ClientResourceManager.RegisterScript(Page, "~/Resources/Shared/scripts/dnn.jquery.tooltip.js");
			ClientResourceManager.RegisterScript(Page, "~/DesktopModules/Admin/Security/Scripts/dnn.PasswordComparer.js");

			if (PortalSettings.Registration.RegistrationFormType == 0)
			{
				//UserName
				if (!PortalSettings.Registration.UseEmailAsUserName)
				{

					AddField("Username", String.Empty, true,
							String.IsNullOrEmpty(PortalSettings.Registration.UserNameValidator) ? ExcludeTerms : PortalSettings.Registration.UserNameValidator,
							TextBoxMode.SingleLine);
				}

				//Password
				if (!PortalSettings.Registration.RandomPassword)
				{
					AddPasswordStrengthField("Password", "Membership", true);

					if (PortalSettings.Registration.RequirePasswordConfirm)
					{
						AddPasswordConfirmField("PasswordConfirm", "Membership", true);
					}
				}

				//Password Q&A
				if (MembershipProviderConfig.RequiresQuestionAndAnswer)
				{
					AddField("PasswordQuestion", "Membership", true, String.Empty, TextBoxMode.SingleLine);
					AddField("PasswordAnswer", "Membership", true, String.Empty, TextBoxMode.SingleLine);
				}

				//DisplayName
				if (String.IsNullOrEmpty(PortalSettings.Registration.DisplayNameFormat))
				{
					AddField("DisplayName", String.Empty, true, String.Empty, TextBoxMode.SingleLine);
				}
				else
				{
					AddField("FirstName", String.Empty, true, String.Empty, TextBoxMode.SingleLine);
					AddField("LastName", String.Empty, true, String.Empty, TextBoxMode.SingleLine);
				}

				//Email
				AddField("Email", String.Empty, true, PortalSettings.Registration.EmailValidator, TextBoxMode.SingleLine);

				if (PortalSettings.Registration.RequireValidProfile)
				{
					foreach (ProfilePropertyDefinition property in User.Profile.ProfileProperties)
					{
						if (property.Required)
						{
							AddProperty(property);
						}
					}
				}
			}
			else
			{
				var fields = PortalSettings.Registration.RegistrationFields.Split(',').ToList();
				//append question/answer field when RequiresQuestionAndAnswer is enabled in config.
				if (MembershipProviderConfig.RequiresQuestionAndAnswer)
				{
					if (!fields.Contains("PasswordQuestion"))
					{
						fields.Add("PasswordQuestion");
					}
					if (!fields.Contains("PasswordAnswer"))
					{
						fields.Add("PasswordAnswer");
					}
				}

				foreach (string field in fields)
				{
					var trimmedField = field.Trim();
					switch (trimmedField)
					{
						case "Username":
							AddField("Username", String.Empty, true, String.IsNullOrEmpty(PortalSettings.Registration.UserNameValidator)
																		? ExcludeTerms : PortalSettings.Registration.UserNameValidator,
																		TextBoxMode.SingleLine);
							break;
						case "Email":
							AddField("Email", String.Empty, true, PortalSettings.Registration.EmailValidator, TextBoxMode.SingleLine);
							break;
						case "Password":
							AddPasswordStrengthField(trimmedField, "Membership", true);
							break;
						case "PasswordConfirm":
							AddPasswordConfirmField(trimmedField, "Membership", true);
							break;
						case "PasswordQuestion":
						case "PasswordAnswer":
							AddField(trimmedField, "Membership", true, String.Empty, TextBoxMode.SingleLine);
							break;
						case "DisplayName":
							AddField(trimmedField, String.Empty, true, ExcludeTerms, TextBoxMode.SingleLine);
							break;
						default:
							ProfilePropertyDefinition property = User.Profile.GetProperty(trimmedField);
							if (property != null)
							{
								AddProperty(property);
							}
							break;
					}
				}
			}

			//Verify that the current user has access to this page
			if (PortalSettings.UserRegistration == (int)Globals.PortalRegistrationType.NoRegistration && Request.IsAuthenticated == false)
			{
				Response.Redirect(Globals.NavigateURL("Access Denied"), false);
				Context.ApplicationInstance.CompleteRequest();
			}

			cancelLink.NavigateUrl = GetRedirectUrl(false);
			registerButton.Click += registerButton_Click;

			if (PortalSettings.Registration.UseAuthProviders)
			{
				List<AuthenticationInfo> authSystems = AuthenticationController.GetEnabledAuthenticationServices();
				foreach (AuthenticationInfo authSystem in authSystems)
				{
					try
					{
						var authLoginControl = (AuthenticationLoginBase)LoadControl("~/" + authSystem.LoginControlSrc);
						if (authSystem.AuthenticationType != "DNN")
						{
							BindLoginControl(authLoginControl, authSystem);
							//Check if AuthSystem is Enabled
							if (authLoginControl.Enabled && authLoginControl.SupportsRegistration)
							{
								authLoginControl.Mode = AuthMode.Register;

								//Add Login Control to List
								_loginControls.Add(authLoginControl);
							}
						}
					}
					catch (Exception ex)
					{
						Exceptions.LogException(ex);
					}
				}
			}
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			if (Request.IsAuthenticated)
			{
				//if a Login Page has not been specified for the portal
				if (Globals.IsAdminControl())
				{
					//redirect to current page 
					Response.Redirect(Globals.NavigateURL(), true);
				}
				else //make module container invisible if user is not a page admin
				{
					if (!TabPermissionController.CanAdminPage())
					{
						ContainerControl.Visible = false;
					}
				}
			}

			if (PortalSettings.Registration.UseCaptcha)
			{
				captchaRow.Visible = true;
				ctlCaptcha.ErrorMessage = Localization.GetString("InvalidCaptcha", LocalResourceFile);
				ctlCaptcha.Text = Localization.GetString("CaptchaText", LocalResourceFile);
			}

			if (PortalSettings.Registration.UseAuthProviders && String.IsNullOrEmpty(AuthenticationType))
			{
				foreach (AuthenticationLoginBase authLoginControl in _loginControls)
				{
					socialLoginControls.Controls.Add(authLoginControl);
				}
			}

			//Display relevant message
			userHelpLabel.Text = Localization.GetSystemMessage(PortalSettings, "MESSAGE_REGISTRATION_INSTRUCTIONS");
			switch (PortalSettings.UserRegistration)
			{
				case (int)Globals.PortalRegistrationType.PrivateRegistration:
					userHelpLabel.Text += Localization.GetString("PrivateMembership", Localization.SharedResourceFile);
					break;
				case (int)Globals.PortalRegistrationType.PublicRegistration:
					userHelpLabel.Text += Localization.GetString("PublicMembership", Localization.SharedResourceFile);
					break;
				case (int)Globals.PortalRegistrationType.VerifiedRegistration:
					userHelpLabel.Text += Localization.GetString("VerifiedMembership", Localization.SharedResourceFile);
					break;
			}
			userHelpLabel.Text += Localization.GetString("Required", LocalResourceFile);
			userHelpLabel.Text += Localization.GetString("RegisterWarning", LocalResourceFile);

			userForm.DataSource = User;
			if (!Page.IsPostBack)
			{
				userForm.DataBind();
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);

			var confirmPasswordOptions = new DnnConfirmPasswordOptions()
			{
				FirstElementSelector = "." + PasswordStrengthTextBoxCssClass,
				SecondElementSelector = "." + ConfirmPasswordTextBoxCssClass,
				ContainerSelector = ".dnnRegistrationForm",
				UnmatchedCssClass = "unmatched",
				MatchedCssClass = "matched"
			};

			var optionsAsJsonString = Json.Serialize(confirmPasswordOptions);
			var script = string.Format("dnn.initializePasswordComparer({0});{1}", optionsAsJsonString, Environment.NewLine);

			if (ScriptManager.GetCurrent(Page) != null)
			{
				// respect MS AJAX
				ScriptManager.RegisterStartupScript(Page, GetType(), "ConfirmPassword", script, true);
			}
			else
			{
				Page.ClientScript.RegisterStartupScript(GetType(), "ConfirmPassword", script, true);
			}

		}

		#endregion

		#region Private Methods

		private void AddField(string dataField, string dataMember, bool required, string regexValidator, TextBoxMode textMode)
		{
			if (userForm.Items.Any(i => i.ID == dataField))
			{
				return;
			}

			var formItem = new DnnFormTextBoxItem
			{
				ID = dataField,
				DataField = dataField,
				DataMember = dataMember,
				Visible = true,
				Required = required,
				TextMode = textMode
			};
			if (!String.IsNullOrEmpty(regexValidator))
			{
				formItem.ValidationExpression = regexValidator;
			}
			userForm.Items.Add(formItem);
		}

		private void AddPasswordStrengthField(string dataField, string dataMember, bool required)
		{
			DnnFormItemBase formItem;

			if (Host.EnableStrengthMeter)
			{
				formItem = new DnnFormPasswordItem
				{
					TextBoxCssClass = PasswordStrengthTextBoxCssClass,
					ContainerCssClass = "password-strength-container"
				};
			}
			else
			{
				formItem = new DnnFormTextBoxItem
				{
					TextMode = TextBoxMode.Password,
					TextBoxCssClass = PasswordStrengthTextBoxCssClass,
				};
			}

			formItem.ID = dataField;
			formItem.DataField = dataField;
			formItem.DataMember = dataMember;
			formItem.Visible = true;
			formItem.Required = required;

			userForm.Items.Add(formItem);

		}

		private void AddPasswordConfirmField(string dataField, string dataMember, bool required)
		{

			var formItem = new DnnFormTextBoxItem
			{
				ID = dataField,
				DataField = dataField,
				DataMember = dataMember,
				Visible = true,
				Required = required,
				TextMode = TextBoxMode.Password,
				TextBoxCssClass = ConfirmPasswordTextBoxCssClass,
				ClearContentInPasswordMode = true
			};
			userForm.Items.Add(formItem);

		}

		private void AddProperty(ProfilePropertyDefinition property)
		{
			if (userForm.Items.Any(i => i.ID == property.PropertyName))
			{
				return;
			}

			var controller = new ListController();
			ListEntryInfo imageType = controller.GetListEntryInfo("DataType", "Image");
			if (property.DataType != imageType.EntryID)
			{
				DnnFormEditControlItem formItem = new DnnFormEditControlItem
				{
					ID = property.PropertyName,
					ResourceKey = String.Format("ProfileProperties_{0}", property.PropertyName),
					LocalResourceFile = "~/DesktopModules/Admin/Security/App_LocalResources/Profile.ascx.resx",
					ValidationMessageSuffix = ".Validation",
					ControlType = EditorInfo.GetEditor(property.DataType),
					DataMember = "Profile",
					DataField = property.PropertyName,
					Visible = property.Visible,
					Required = property.Required
				};
				//To check if the property has a deafult value
				if (!String.IsNullOrEmpty(property.DefaultValue))
				{
					formItem.Value = property.DefaultValue;
				}
				if (!String.IsNullOrEmpty(property.ValidationExpression))
				{
					formItem.ValidationExpression = property.ValidationExpression;
				}
				userForm.Items.Add(formItem);
			}

		}

		private void BindLoginControl(AuthenticationLoginBase authLoginControl, AuthenticationInfo authSystem)
		{
			//set the control ID to the resource file name ( ie. controlname.ascx = controlname )
			//this is necessary for the Localization in PageBase
			authLoginControl.AuthenticationType = authSystem.AuthenticationType;
			authLoginControl.ID = Path.GetFileNameWithoutExtension(authSystem.LoginControlSrc) + "_" + authSystem.AuthenticationType;
			authLoginControl.LocalResourceFile = authLoginControl.TemplateSourceDirectory + "/" + Localization.LocalResourceDirectory + "/" +
												 Path.GetFileNameWithoutExtension(authSystem.LoginControlSrc);
			authLoginControl.RedirectURL = GetRedirectUrl();
			authLoginControl.ModuleConfiguration = ModuleConfiguration;

			authLoginControl.UserAuthenticated += UserAuthenticated;
		}

		private void CreateUser()
		{
			//Update DisplayName to conform to Format
			UpdateDisplayName();

			User.Membership.Approved = PortalSettings.UserRegistration == (int)Globals.PortalRegistrationType.PublicRegistration;
			var user = User;
			CreateStatus = UserController.CreateUser(ref user);

			DataCache.ClearPortalCache(PortalId, true);

			try
			{
				if (CreateStatus == UserCreateStatus.Success)
				{
					//hide the succesful captcha
					captchaRow.Visible = false;

					//Assocate alternate Login with User and proceed with Login
					if (!String.IsNullOrEmpty(AuthenticationType))
					{
						AuthenticationController.AddUserAuthentication(User.UserID, AuthenticationType, UserToken);
					}

					string strMessage = CompleteUserCreation(CreateStatus, user, true, IsRegister);

					if ((string.IsNullOrEmpty(strMessage)))
					{
						Response.Redirect(GetRedirectUrl(), true);
					}
					else
					{
						RegistrationForm.Visible = false;
						registerButton.Visible = false;
						cancelLink.Attributes["resourcekey"] = "Close";
						RegistrationForm.Parent.Controls.Add(cancelLink);
					}
				}
				else
				{
					AddLocalizedModuleMessage(UserController.GetUserCreateStatus(CreateStatus), ModuleMessage.ModuleMessageType.RedError, true);
				}
			}
			catch (Exception exc) //Module failed to load
			{
				Exceptions.ProcessModuleLoadException(this, exc);
			}
		}

		private void UpdateDisplayName()
		{
			//Update DisplayName to conform to Format
			if (!string.IsNullOrEmpty(PortalSettings.Registration.DisplayNameFormat))
			{
				User.UpdateDisplayName(PortalSettings.Registration.DisplayNameFormat);
			}
		}

		private bool Validate()
		{
		    if (!string.IsNullOrEmpty(gotcha.Value))
		    {
		        return false;
		    }

			CreateStatus = UserCreateStatus.AddUser;
			var portalSecurity = new PortalSecurity();

			//Check User Editor
			bool _IsValid = userForm.IsValid;

			if (PortalSettings.Registration.RegistrationFormType == 0)
			{
				//Update UserName
				if (PortalSettings.Registration.UseEmailAsUserName)
				{
					User.Username = User.Email;
					if (String.IsNullOrEmpty(User.DisplayName))
					{
						User.DisplayName = User.Email.Substring(0, User.Email.IndexOf("@", StringComparison.Ordinal));
					}
				}

				//Check Password is valid
				if (!PortalSettings.Registration.RandomPassword)
				{
					//Check Password is Valid
					if (CreateStatus == UserCreateStatus.AddUser && !UserController.ValidatePassword(User.Membership.Password))
					{
						CreateStatus = UserCreateStatus.InvalidPassword;
					}

					if (PortalSettings.Registration.RequirePasswordConfirm && String.IsNullOrEmpty(AuthenticationType))
					{
						if (User.Membership.Password != User.Membership.PasswordConfirm)
						{
							CreateStatus = UserCreateStatus.PasswordMismatch;
						}
					}
				}
				else
				{
					//Generate a random password for the user
					User.Membership.Password = UserController.GeneratePassword();
					User.Membership.PasswordConfirm = User.Membership.Password;
				}

			}
			else
			{
				//Set Username to Email
				if (String.IsNullOrEmpty(User.Username))
				{
					User.Username = User.Email;
				}

				//Set DisplayName
				if (String.IsNullOrEmpty(User.DisplayName))
				{
					User.DisplayName = String.IsNullOrEmpty(User.FirstName + " " + User.LastName)
										   ? User.Email.Substring(0, User.Email.IndexOf("@", StringComparison.Ordinal))
										   : User.FirstName + " " + User.LastName;
				}

				//Random Password
				if (String.IsNullOrEmpty(User.Membership.Password))
				{
					//Generate a random password for the user
					User.Membership.Password = UserController.GeneratePassword();
				}

				//Password Confirm
				if (!String.IsNullOrEmpty(User.Membership.PasswordConfirm))
				{
					if (User.Membership.Password != User.Membership.PasswordConfirm)
					{
						CreateStatus = UserCreateStatus.PasswordMismatch;
					}
				}
			}

			//Validate banned password
			var settings = new MembershipPasswordSettings(User.PortalID);

			if (settings.EnableBannedList)
			{
				var m = new MembershipPasswordController();
				if (m.FoundBannedPassword(User.Membership.Password) || User.Username == User.Membership.Password)
				{
					CreateStatus = UserCreateStatus.BannedPasswordUsed;
				}

			}
			//Validate Profanity
			if (PortalSettings.Registration.UseProfanityFilter)
			{
				if (!portalSecurity.ValidateInput(User.Username, PortalSecurity.FilterFlag.NoProfanity))
				{
					CreateStatus = UserCreateStatus.InvalidUserName;
				}
				if (!String.IsNullOrEmpty(User.DisplayName))
				{
					if (!portalSecurity.ValidateInput(User.DisplayName, PortalSecurity.FilterFlag.NoProfanity))
					{
						CreateStatus = UserCreateStatus.InvalidDisplayName;
					}
				}
			}

			//Validate Unique User Name
			UserInfo user = UserController.GetUserByName(PortalId, User.Username);
			if (user != null)
			{
				if (PortalSettings.Registration.UseEmailAsUserName)
				{
					CreateStatus = UserCreateStatus.DuplicateEmail;
				}
				else
				{
					CreateStatus = UserCreateStatus.DuplicateUserName;
					int i = 1;
					string userName = null;
					while (user != null)
					{
						userName = User.Username + "0" + i.ToString(CultureInfo.InvariantCulture);
						user = UserController.GetUserByName(PortalId, userName);
						i++;
					}
					User.Username = userName;
				}
			}

			//Validate Unique Display Name
			if (CreateStatus == UserCreateStatus.AddUser && PortalSettings.Registration.RequireUniqueDisplayName)
			{
				user = UserController.Instance.GetUserByDisplayname(PortalId, User.DisplayName);
				if (user != null)
				{
					CreateStatus = UserCreateStatus.DuplicateDisplayName;
					int i = 1;
					string displayName = null;
					while (user != null)
					{
						displayName = User.DisplayName + " 0" + i.ToString(CultureInfo.InvariantCulture);
						user = UserController.Instance.GetUserByDisplayname(PortalId, displayName);
						i++;
					}
					User.DisplayName = displayName;
				}
			}

			//Check Question/Answer
			if (CreateStatus == UserCreateStatus.AddUser && MembershipProviderConfig.RequiresQuestionAndAnswer)
			{
				if (string.IsNullOrEmpty(User.Membership.PasswordQuestion))
				{
					//Invalid Question
					CreateStatus = UserCreateStatus.InvalidQuestion;
				}
				if (CreateStatus == UserCreateStatus.AddUser)
				{
					if (string.IsNullOrEmpty(User.Membership.PasswordAnswer))
					{
						//Invalid Question
						CreateStatus = UserCreateStatus.InvalidAnswer;
					}
				}
			}

			if (CreateStatus != UserCreateStatus.AddUser)
			{
				_IsValid = false;
			}
			return _IsValid;
		}

		private string GetRedirectUrl(bool checkSetting = true)
		{
			var redirectUrl = "";
			var redirectAfterRegistration = PortalSettings.Registration.RedirectAfterRegistration;
			if (checkSetting && redirectAfterRegistration > 0) //redirect to after registration page
			{
				redirectUrl = Globals.NavigateURL(redirectAfterRegistration);
			}
			else
			{
				if (Request.QueryString["returnurl"] != null)
				{
					//return to the url passed to register
					redirectUrl = HttpUtility.UrlDecode(Request.QueryString["returnurl"]);
					//redirect url should never contain a protocol ( if it does, it is likely a cross-site request forgery attempt )
					if (redirectUrl.Contains("://") &&
						!redirectUrl.StartsWith(Globals.AddHTTP(PortalSettings.PortalAlias.HTTPAlias),
							StringComparison.InvariantCultureIgnoreCase))
					{
						redirectUrl = "";
					}
					if (redirectUrl.Contains("?returnurl"))
					{
						string baseURL = redirectUrl.Substring(0,
							redirectUrl.IndexOf("?returnurl", StringComparison.Ordinal));
						string returnURL =
							redirectUrl.Substring(redirectUrl.IndexOf("?returnurl", StringComparison.Ordinal) + 11);

						redirectUrl = string.Concat(baseURL, "?returnurl", HttpUtility.UrlEncode(returnURL));
					}
				}
				if (String.IsNullOrEmpty(redirectUrl))
				{
					//redirect to current page 
					redirectUrl = Globals.NavigateURL();
				}
			}

			return redirectUrl;
		}

		private void registerButton_Click(object sender, EventArgs e)
		{
			if ((PortalSettings.Registration.UseCaptcha && ctlCaptcha.IsValid) || !PortalSettings.Registration.UseCaptcha)
			{
				if (IsValid)
				{
                    if (PortalSettings.UserRegistration != (int)Globals.PortalRegistrationType.NoRegistration)
                    {
                        CreateUser();
                    }

				}
				else
				{
					if (CreateStatus != UserCreateStatus.AddUser)
					{
						AddLocalizedModuleMessage(UserController.GetUserCreateStatus(CreateStatus), ModuleMessage.ModuleMessageType.RedError, true);
					}
				}
			}
		}

		private void UserAuthenticated(object sender, UserAuthenticatedEventArgs e)
		{
			NameValueCollection profileProperties = e.Profile;

			User.Username = e.UserToken;
			AuthenticationType = e.AuthenticationType;
			UserToken = e.UserToken;

			foreach (string key in profileProperties)
			{
				switch (key)
				{
					case "FirstName":
						User.FirstName = profileProperties[key];
						break;
					case "LastName":
						User.LastName = profileProperties[key];
						break;
					case "Email":
						User.Email = profileProperties[key];
						break;
					case "DisplayName":
						User.DisplayName = profileProperties[key];
						break;
					default:
						User.Profile.SetProfileProperty(key, profileProperties[key]);
						break;
				}
			}

			//Generate a random password for the user
			User.Membership.Password = UserController.GeneratePassword();

			if (!String.IsNullOrEmpty(User.Email))
			{
				CreateUser();
			}
			else
			{
				AddLocalizedModuleMessage(LocalizeString("NoEmail"), ModuleMessage.ModuleMessageType.RedError, true);
				foreach (DnnFormItemBase formItem in userForm.Items)
				{
					formItem.Visible = formItem.DataField == "Email";
				}
				userForm.DataBind();
			}
		}

		#endregion
	}
}
